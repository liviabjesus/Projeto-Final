from datetime import datetime
from app import app, db
from flask import jsonify, render_template, session, url_for, request, redirect
from app.forms import LoginForm, UserInfoForm, UserPasswordForm
from app.models import User, Cronometro, Agua
from flask_login import login_user, logout_user, current_user, login_required

@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        user = form.login()
        login_user(user, remember=True)
        return redirect(url_for('menu'))

    return render_template('login.html', form=form)

@app.route('/cadastro/etapa1', methods=['GET', 'POST'])
def cadastro_etapa1():
    form = UserInfoForm()
    if form.validate_on_submit():
        # Armazene os dados do formulário na sessão para a segunda etapa
        session['cadastro_data'] = form.data
        return redirect(url_for('cadastro_etapa2'))
    return render_template('cadastro_etapa1.html', form=form)

@app.route('/cadastro/etapa2', methods=['GET', 'POST'])
def cadastro_etapa2():
    form = UserPasswordForm()
    if form.validate_on_submit():
        user_info_form = UserInfoForm(data=session['cadastro_data'])
        user = form.save(user_info_form)
        login_user(user, remember=True)
        session.pop('cadastro_data', None)  # Limpa a sessão após o cadastro
        return redirect(url_for('menu'))
    return render_template('cadastro_etapa2.html', form=form)


@app.route('/menu/')
@login_required
def menu():
    return render_template('menu.html')

@app.route('/sair/')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))
from datetime import datetime, timedelta

@app.route('/cronometro/')
@login_required
def cronometro():
    cronometro = Cronometro.query.filter_by(user_id=current_user.id).first()

    if cronometro is None:
        cronometro = Cronometro(user_id=current_user.id)
        db.session.add(cronometro)
        db.session.commit()

    # Se o cronômetro estiver em execução, calcular o tempo decorrido
    if cronometro.is_running and cronometro.start_time:
        delta = datetime.utcnow() - cronometro.start_time
        cronometro.elapsed_time += int(delta.total_seconds() * 1000)
        cronometro.start_time = datetime.utcnow()  # Atualiza o tempo de início
        db.session.commit()

    elapsed_seconds = cronometro.elapsed_time // 1000
    minutes, seconds = divmod(elapsed_seconds, 60)
    hours, minutes = divmod(minutes, 60)

    # Redireciona para a mesma página a cada segundo para atualizar o cronômetro
    return render_template('cronometro.html', hours=hours, minutes=minutes, seconds=seconds, is_running=cronometro.is_running, refresh_interval=1)

@app.route('/cronometro/iniciar', methods=['POST'])
@login_required
def iniciar_cronometro():
    cronometro = Cronometro.query.filter_by(user_id=current_user.id).first()

    if cronometro and not cronometro.is_running:
        cronometro.start_time = datetime.utcnow()
        cronometro.is_running = True
        db.session.commit()

    return redirect(url_for('cronometro'))

@app.route('/cronometro/pausar', methods=['POST'])
@login_required
def pausar_cronometro():
    cronometro = Cronometro.query.filter_by(user_id=current_user.id).first()

    if cronometro and cronometro.is_running:
        delta = datetime.utcnow() - cronometro.start_time
        cronometro.elapsed_time += int(delta.total_seconds() * 1000)
        cronometro.is_running = False
        cronometro.start_time = None
        db.session.commit()

    return redirect(url_for('cronometro'))

@app.route('/cronometro/resetar', methods=['POST'])
@login_required
def resetar_cronometro():
    cronometro = Cronometro.query.filter_by(user_id=current_user.id).first()

    if cronometro:
        cronometro.elapsed_time = 0
        cronometro.is_running = False
        cronometro.start_time = None
        db.session.commit()

    return redirect(url_for('cronometro'))


from datetime import date

@app.route('/agua/', methods=['GET', 'POST'])
@login_required
def agua():
    current_user.reset_water_count_if_new_day()
    return render_template('agua.html', water_count=current_user.water_count)

@app.route('/agua/incrementar', methods=['POST'])
@login_required
def incrementar_agua():
    current_user.reset_water_count_if_new_day()
    current_user.water_count += 1
    current_user.last_water_update = date.today()
    db.session.commit()
    return redirect(url_for('agua'))

@app.route('/agua/resetar', methods=['POST'])
@login_required
def resetar_agua():
    current_user.water_count = 0
    current_user.last_water_update = date.today()
    db.session.commit()
    return redirect(url_for('agua'))

@app.route('/calorias/', methods=['GET', 'POST'])
@login_required
def calorias():
    if request.method == 'POST':
        try:
            proteinas = float(request.form['proteinas'])
            carboidratos = float(request.form['carboidratos'])
            gorduras = float(request.form['gorduras'])

            # Calcular calorias
            calorias_proteinas = proteinas * 4
            calorias_carboidratos = carboidratos * 4
            calorias_gorduras = gorduras * 9

            total_calorias = calorias_proteinas + calorias_carboidratos + calorias_gorduras

            return render_template('calorias.html', total_calorias=total_calorias)

        except ValueError:
            return render_template('calorias.html', error='Valores inválidos fornecidos.')
    
    return render_template('calorias.html')

# @app.route('/pagina1/')
# @login_required
# def pag1():
#     return render_template('pagInfo/pag1.html')

from flask import Flask, render_template, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'sua_chave_secreta_aqui'

@app.route('/')
def menu():
    return render_template('menu.html')

@app.route('/usuario')
def usuario():
    if 'logged_in' in session:
        return render_template('usuario.html')
    else:
        return redirect(url_for('login'))

@app.route('/login')
def login():
    # Página de login (você pode definir sua própria lógica de login aqui)
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('menu'))

if __name__ == '__main__':
    app.run(debug=True)


# from flask import Flask, jsonify, request

# app = Flask(__name__)

# # Suponha que você tenha uma variável global ou um método para gerenciar o cronômetro
# cronometro_tempo = {'hours': 0, 'minutes': 0, 'seconds': 0}  # Exemplo de tempo inicial

# @app.route('/get_timer')
# def get_timer():
#     # Retorna o tempo atual do cronômetro em formato JSON
#     return jsonify(cronometro_tempo)

# @app.route('/iniciar_cronometro', methods=['POST'])
# def iniciar_cronometro():
#     # Lógica para iniciar o cronômetro
#     return redirect(url_for('cronometro'))  # Redireciona para a página do cronômetro

# @app.route('/pausar_cronometro', methods=['POST'])
# def pausar_cronometro():
#     # Lógica para pausar o cronômetro
#     return redirect(url_for('cronometro'))

# @app.route('/resetar_cronometro', methods=['POST'])
# def resetar_cronometro():
#     global cronometro_tempo
#     cronometro_tempo = {'hours': 0, 'minutes': 0, 'seconds': 0}
#     return redirect(url_for('cronometro'))

# if __name__ == '__main__':
#     app.run(debug=True)
