Projeto Feito Por:
* Eduardo Manske
* Juliana da Silva Masnke
* Livia Schrute

Projeto Live Well apresentado como projeto final

*** Instalação ***

Passo 1:
Abrir o arquivo do programa em um editor de código

Passo 2:
Abrir o terminal

Passo 3:
.venv\Scripts\activate

Passo 4:
pip install -r requirements.txt

Passo 5:
Selecionar o interpretador correto (venv : venv)

Passo 6:
Executar o main.py